const express = require('express');
const app = express();
const port = 3002;

// Configurar o Express para usar EJS
app.set('view engine', 'ejs');

// Definir a pasta de arquivos estáticos (como CSS)
app.use(express.static('public'));

// Rota para a página inicial
app.get('/', (req, res) => {
    res.render('petshop');
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
